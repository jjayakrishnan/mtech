import os
import json
import asyncio
from openai import OpenAI
from dotenv import load_dotenv
from pypdf import PdfReader

# -----------------------------------
# Setup
# -----------------------------------

load_dotenv(override=True)

client = OpenAI(
    api_key=os.getenv("OPENAI_API_KEY")
)

MODEL = "gpt-5-nano"
BLACKBOARD_FILE = "blackboard.json"

# -----------------------------------
# Blackboard
# -----------------------------------

def load_blackboard():

    if os.path.exists(BLACKBOARD_FILE):
        with open(BLACKBOARD_FILE, "r") as f:
            return json.load(f)

    return {
        "paper_text": None,
        "validation": None,
        "review_comments": None,
        "summary": None,
        "status": "INIT"
    }


def save_blackboard(board):

    with open(BLACKBOARD_FILE, "w") as f:
        json.dump(board, f, indent=4)


def initialize_blackboard(paper_text):

    board = {
        "paper_text": paper_text,
        "validation": None,
        "review_comments": None,
        "summary": None,
        "status": "INIT"
    }

    save_blackboard(board)


# -----------------------------------
# PDF Reader
# -----------------------------------

def read_pdf(pdf_path):

    reader = PdfReader(pdf_path)
    text = ""

    for page in reader.pages:

        page_text = page.extract_text()

        if page_text:
            text += page_text + "\n"

    return text


# -----------------------------------
# OpenAI Helper
# -----------------------------------

def ask_llm(system_prompt, user_prompt):

    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {
                "role": "system",
                "content": system_prompt
            },
            {
                "role": "user",
                "content": user_prompt
            }
        ]
    )

    return response.choices[0].message.content


# -----------------------------------
# Blackboard Agents
# -----------------------------------

class ValidationAgent:

    async def run(self):

        board = load_blackboard()

        # Run only if validation absent
        if board["validation"] is not None:
            return

        print("\n[Validation Agent]")

        result = ask_llm(
            "Validate research paper briefly. "
            "Start with VALID or INVALID.",
            board["paper_text"][:6000]
        )

        print(result)

        board["validation"] = result

        if "INVALID" in result.upper():
            board["status"] = "REJECTED"
        else:
            board["status"] = "VALIDATED"

        save_blackboard(board)


class ReviewAgent:

    async def run(self):

        board = load_blackboard()

        # Requires validation
        if board["status"] != "VALIDATED":
            return

        # Avoid duplicate work
        if board["review_comments"] is not None:
            return

        print("\n[Review Agent]")

        review = ask_llm(
            "Act as academic reviewer. "
            "Provide:\n"
            "1 Strengths\n"
            "2 Weaknesses\n"
            "3 Suggestions",
            board["paper_text"][:6000]
        )

        board["review_comments"] = review
        board["status"] = "REVIEWED"

        save_blackboard(board)


class SummaryAgent:

    async def run(self):

        board = load_blackboard()

        # Requires review
        if board["status"] != "REVIEWED":
            return

        if board["summary"] is not None:
            return

        print("\n[Summary Agent]")

        summary = ask_llm(
            "Summarize this paper in about 300 words.",
            board["paper_text"][:6000]
        )

        board["summary"] = summary
        board["status"] = "COMPLETED"

        save_blackboard(board)


# -----------------------------------
# Blackboard Scheduler
# -----------------------------------

async def blackboard_loop():

    validation = ValidationAgent()
    review = ReviewAgent()
    summary = SummaryAgent()

    while True:

        board = load_blackboard()

        status = board["status"]

        if status in [
            "COMPLETED",
            "REJECTED"
        ]:
            break

        # Agents independently inspect blackboard
        await validation.run()
        await review.run()
        await summary.run()

        await asyncio.sleep(1)

    print("\nBLACKBOARD PROCESS COMPLETE")

    board = load_blackboard()

    print("\nStatus:")
    print(board["status"])

    print("\nValidation:")
    print(board["validation"])

    print("\nReview:")
    print(board["review_comments"])

    print("\nSummary:")
    print(board["summary"])


# -----------------------------------
# Run
# -----------------------------------

pdf_file = "paper.pdf"

paper_text = read_pdf(pdf_file)

initialize_blackboard(paper_text)

asyncio.run(
    blackboard_loop()
)