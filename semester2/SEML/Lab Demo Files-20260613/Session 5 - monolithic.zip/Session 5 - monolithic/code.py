# pip install -r requirements.txt
# Monolithic Logistic Regression Deployment using FastAPI
# This is an Iris Dataset. 
# Model expects four features: [sepal_length, sepal_width, petal_length, petal_width]
# Predictions possible
# 0 → Setosa, 1 → Versicolor, 2 → Virginica

from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import uvicorn

# Initialize FastAPI app
app = FastAPI()

# Load Logistic Regression model
model = joblib.load("logistic_regression_model.pkl")

# Input schema
class InputData(BaseModel):
    features: list

# Prediction endpoint
@app.post("/predict")
def predict(data: InputData):
    prediction = model.predict([data.features])
    
    return {
        "prediction": int(prediction[0])
    }

# Run application
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=5000)