import os
import json
import asyncio
from openai import OpenAI
from dotenv import load_dotenv
from pypdf import PdfReader

# -----------------------------------
# Setup
# -----------------------------------

load_dotenv(override=True)

client = OpenAI(
    api_key=os.getenv("OPENAI_API_KEY")
)

MODEL = "gpt-5-nano"
STATE_FILE = "choreography_state.json"

# -----------------------------------
# Shared Event Store
# -----------------------------------

def load_state():

    if os.path.exists(STATE_FILE):
        with open(STATE_FILE, "r") as f:
            return json.load(f)

    return {
        "events": [],
        "metadata": {}
    }


def save_state(state):

    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=4)


def publish_event(event_name, metadata=None):

    state = load_state()

    state["events"].append(event_name)

    if metadata:
        state["metadata"].update(metadata)

    save_state(state)

    print(f"\nEVENT PUBLISHED -> {event_name}")


def reset_state():

    save_state({
        "events": [],
        "metadata": {}
    })

# -----------------------------------
# PDF Reader
# -----------------------------------

def read_pdf(pdf_path):

    reader = PdfReader(pdf_path)
    text = ""

    for page in reader.pages:

        page_text = page.extract_text()

        if page_text:
            text += page_text + "\n"

    return text


# -----------------------------------
# OpenAI Helper
# -----------------------------------

def ask_llm(system_prompt, user_prompt):

    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {
                "role": "system",
                "content": system_prompt
            },
            {
                "role": "user",
                "content": user_prompt
            }
        ]
    )

    return response.choices[0].message.content


# -----------------------------------
# Agents
# -----------------------------------

class ValidationAgent:

    async def handle(self, paper_text):

        print("\n[Validation Agent]")

        result = ask_llm(
            "Validate research paper briefly. "
            "Start with VALID or INVALID.",
            paper_text[:6000]
        )

        print(result)

        if "INVALID" in result.upper():

            publish_event(
                "VALIDATION_FAILED"
            )

            raise Exception(
                "Validation failed"
            )

        publish_event(
            "VALIDATED",
            {
                "validation": result
            }
        )


    async def compensate(self):

        print("Undo validation")

        publish_event(
            "VALIDATION_COMPENSATED"
        )


class ReviewAgent:

    async def handle(self, paper_text):

        print("\n[Review Agent]")

        review = ask_llm(
            "Act as an academic reviewer. "
            "Provide:\n"
            "1 Strengths\n"
            "2 Weaknesses\n"
            "3 Suggestions",
            paper_text[:6000]
        )

        publish_event(
            "REVIEWED",
            {
                "review_comments": review
            }
        )


    async def compensate(self):

        print("Delete review comments")

        publish_event(
            "REVIEW_COMPENSATED"
        )


class SummaryAgent:

    async def handle(self, paper_text):

        print("\n[Summary Agent]")

        summary = ask_llm(
            "Summarize this research paper in about 300 words.",
            paper_text[:6000]
        )

        publish_event(
            "SUMMARIZED",
            {
                "summary": summary
            }
        )


    async def compensate(self):

        print("Delete summary")

        publish_event(
            "SUMMARY_COMPENSATED"
        )


# -----------------------------------
# Choreography Runtime
# -----------------------------------

async def choreography_run(pdf_path):

    reset_state()

    paper_text = read_pdf(pdf_path)

    validation = ValidationAgent()
    review = ReviewAgent()
    summary = SummaryAgent()

    try:

        # Event 1
        await validation.handle(
            paper_text
        )

        state = load_state()

        if "VALIDATED" in state["events"]:

            # Event 2
            await review.handle(
                paper_text
            )

            state = load_state()

            if "REVIEWED" in state["events"]:

                # Event 3
                await summary.handle(
                    paper_text
                )

                state = load_state()

                if "SUMMARIZED" in state["events"]:

                    publish_event(
                        "SAGA_SUCCESS"
                    )

                    print(
                        "\nCHOREOGRAPHY SUCCESS"
                    )

                    print(
                        "\n--- FINAL OUTPUT ---"
                    )

                    metadata = state["metadata"]

                    print(
                        "\nValidation:\n"
                    )
                    print(
                        metadata.get(
                            "validation"
                        )
                    )

                    print(
                        "\nReview:\n"
                    )
                    print(
                        metadata.get(
                            "review_comments"
                        )
                    )

                    print(
                        "\nSummary:\n"
                    )
                    print(
                        metadata.get(
                            "summary"
                        )
                    )

    except Exception as e:

        print(
            "\nFailure:",
            e
        )

        print(
            "\nStarting compensation..."
        )

        state = load_state()
        events = state["events"]

        # Compensation provision exists

        if "SUMMARIZED" in events:
            await summary.compensate()

        if "REVIEWED" in events:
            await review.compensate()

        if "VALIDATED" in events:
            await validation.compensate()

        publish_event(
            "SAGA_ROLLBACK"
        )

        print(
            "\nROLLBACK COMPLETE"
        )


# -----------------------------------
# Run
# -----------------------------------

pdf_file = "paper.pdf"

asyncio.run(
    choreography_run(
        pdf_file
    )
)