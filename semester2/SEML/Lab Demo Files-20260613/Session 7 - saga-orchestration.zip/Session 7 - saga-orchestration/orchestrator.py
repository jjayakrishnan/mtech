import os
import json
from openai import OpenAI
from dotenv import load_dotenv
from pypdf import PdfReader

# -----------------------------------
# Setup
# -----------------------------------

load_dotenv(override=True)

client = OpenAI(
    api_key=os.getenv("OPENAI_API_KEY")
)

MODEL = "gpt-5-nano"
STATE_FILE = "saga_state.json"

# -----------------------------------
# State Store
# -----------------------------------

def save_state(state):

    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=4)


def load_state():

    if os.path.exists(STATE_FILE):
        with open(STATE_FILE, "r") as f:
            return json.load(f)

    return {
        "completed_agents": [],
        "metadata": {}
    }

# -----------------------------------
# PDF Reader
# -----------------------------------

def read_pdf(pdf_path):

    reader = PdfReader(pdf_path)
    text = ""

    for page in reader.pages:

        page_text = page.extract_text()

        if page_text:
            text += page_text + "\n"

    return text

# -----------------------------------
# OpenAI Helper
# -----------------------------------

def ask_llm(system_prompt, user_prompt):

    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {
                "role": "system",
                "content": system_prompt
            },
            {
                "role": "user",
                "content": user_prompt
            }
        ]
    )

    return response.choices[0].message.content

# -----------------------------------
# Agents
# -----------------------------------

class ValidationAgent:

    name = "ValidationAgent"

    def execute(self, paper_text):

        print("\n[Validation Agent]")

        result = ask_llm(
            "You validate research papers. "
            "Briefly decide whether the paper looks academically valid. "
            "Start answer with VALID or INVALID.",
            paper_text[:6000]
        )

        print(result)

        if "INVALID" in result.upper():
            raise Exception("Validation failed")

        return {
            "validation": result
        }

    def compensate(self):

        print("Undo validation")


class ReviewAgent:

    name = "ReviewAgent"

    def execute(self, paper_text):

        print("\n[Review Agent]")

        review = ask_llm(
            "Act as an academic reviewer. "
            "Provide concise review comments with:\n"
            "1 Strengths\n"
            "2 Weaknesses\n"
            "3 Suggestions",
            paper_text[:6000]
        )

        return {
            "review_comments": review
        }

    def compensate(self):

        print("Delete review comments")


class SummaryAgent:

    name = "SummaryAgent"

    def execute(self, paper_text):

        print("\n[Summary Agent]")

        summary = ask_llm(
            "Summarize this research paper in about 300 words.",
            paper_text[:6000]
        )

        return {
            "summary": summary
        }

    def compensate(self):

        print("Delete summary")

# -----------------------------------
# Orchestrator
# -----------------------------------

class SagaOrchestrator:

    def __init__(self):

        self.completed = []
        self.state = load_state()

    def update_state(self, agent_name, metadata):

        self.state["completed_agents"].append(agent_name)
        self.state["metadata"].update(metadata)

        save_state(self.state)

    def rollback(self):

        print("\nStarting compensation...")

        for agent in reversed(self.completed):
            agent.compensate()

        self.state = {
            "completed_agents": [],
            "metadata": {}
        }

        save_state(self.state)

        print("\nSAGA ROLLBACK COMPLETE")

    def run(self, pdf_path):

        paper_text = read_pdf(pdf_path)

        validation = ValidationAgent()
        review = ReviewAgent()
        summary = SummaryAgent()

        try:

            # Validation
            v = validation.execute(paper_text)
            self.completed.append(validation)
            self.update_state(validation.name, v)

            # Review
            r = review.execute(paper_text)
            self.completed.append(review)
            self.update_state(review.name, r)

            # Summary
            s = summary.execute(paper_text)
            self.completed.append(summary)
            self.update_state(summary.name, s)

            print("\nSAGA SUCCESS")

            print("\n--- FINAL OUTPUT ---")

            print("\nValidation:")
            print(v["validation"])

            print("\nReview:")
            print(r["review_comments"])

            print("\nSummary:")
            print(s["summary"])

        except Exception as e:

            print("\nFailure:", e)
            self.rollback()

# -----------------------------------
# Run
# -----------------------------------

pdf_file = "paper.pdf"

orchestrator = SagaOrchestrator()
orchestrator.run(pdf_file)