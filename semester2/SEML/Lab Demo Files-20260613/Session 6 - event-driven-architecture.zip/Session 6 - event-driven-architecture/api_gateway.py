# api_gateway.py
# API Gateway / Prediction Service
# Responsibilities: orchestration/routing
#   - Receives HTTP requests from clients
#   - Calls Model Service synchronously to get prediction
#   - Publishes log event to RabbitMQ ASYNCHRONOUSLY (fire-and-forget)
#   - Returns prediction immediately without waiting for logging

from fastapi import FastAPI, HTTPException
from contextlib import asynccontextmanager
from pydantic import BaseModel
import httpx
import aio_pika
import asyncio
import json
import uvicorn

# ── Configuration ────────────────────────────────────────────────────────────
MODEL_URL    = "http://localhost:8001/predict"
RABBITMQ_URL = "amqp://guest:guest@localhost:5672/"
QUEUE_NAME   = "inference_logs"

# Shared RabbitMQ channel (initialised on startup)
_rabbitmq_connection = None
_rabbitmq_channel    = None


# ── Lifespan: open / close RabbitMQ connection ───────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    global _rabbitmq_connection, _rabbitmq_channel

    print("[Gateway] Connecting to RabbitMQ...")
    _rabbitmq_connection = await aio_pika.connect_robust(RABBITMQ_URL)
    _rabbitmq_channel    = await _rabbitmq_connection.channel()

    # Declare durable queue so messages survive RabbitMQ restarts
    await _rabbitmq_channel.declare_queue(QUEUE_NAME, durable=True)
    print(f"[Gateway] Connected. Queue '{QUEUE_NAME}' is ready.")

    yield  # ← application runs here

    await _rabbitmq_connection.close()
    print("[Gateway] RabbitMQ connection closed.")


app = FastAPI(
    title="API Gateway / Prediction Service",
    lifespan=lifespan
)


# ── Request / Response schemas ────────────────────────────────────────────────
class InputData(BaseModel):
    features: list


# ── Async helper: fire-and-forget publish ─────────────────────────────────────
async def _publish_log(log_data: dict):
    """
    Publish a log event to the 'inference_logs' RabbitMQ queue.
    Called as an asyncio Task so the gateway does NOT wait for it.
    """
    try:
        await _rabbitmq_channel.default_exchange.publish(
            aio_pika.Message(
                body=json.dumps(log_data).encode(),
                delivery_mode=aio_pika.DeliveryMode.PERSISTENT,  # survives broker restart
            ),
            routing_key=QUEUE_NAME,
        )
        print(f"[Gateway] Log published to RabbitMQ: {log_data}")
    except Exception as exc:
        print(f"[Gateway] WARNING — failed to publish log: {exc}")


# ── Prediction endpoint ───────────────────────────────────────────────────────
@app.post("/predict")
async def predict(data: InputData):
    """
    Async Logging Flow:
      1. Client sends request here  ← (you are here)
      2. Gateway calls Model Service (sync HTTP, awaited)
      3. Model Service returns prediction
      4. Gateway publishes log to RabbitMQ async (fire-and-forget)
      5. Gateway returns prediction IMMEDIATELY
    """

    # ── Step 2 & 3: call Model Service ───────────────────────────────────────
    try:
        async with httpx.AsyncClient() as client:
            model_response = await client.post(
                MODEL_URL,
                json={"features": data.features},
                timeout=10.0,
            )
        model_response.raise_for_status()
    except httpx.ConnectError:
        raise HTTPException(
            status_code=503,
            detail="Model Service is unavailable. Make sure model_service.py is running on port 8001."
        )
    except httpx.TimeoutException:
        raise HTTPException(
            status_code=504,
            detail="Model Service timed out after 10 seconds."
        )
    except httpx.HTTPStatusError as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Model Service returned an error: {exc.response.status_code}"
        )

    prediction = model_response.json()

    # ── Step 4: publish log asynchronously (fire-and-forget) ─────────────────
    log_event = {
        "features":   data.features,
        "prediction": prediction["prediction"],
    }
    asyncio.create_task(_publish_log(log_event))   # ← does NOT block the response

    # ── Step 5: return immediately ────────────────────────────────────────────
    return prediction


# ── Start server ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
