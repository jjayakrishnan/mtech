# logging_service.py
# Logging Service (FastAPI + RabbitMQ Consumer)
# Responsibilities: observability / history
#   - Consumes log events from the 'inference_logs' RabbitMQ queue (async)
#   - Stores logs in an in-memory "Logs DB"
#   - Exposes GET /logs for querying stored logs
#   - Exposes GET /health to diagnose consumer status

from fastapi import FastAPI
from contextlib import asynccontextmanager
import aio_pika
import asyncio
import json
import uvicorn

# ── Configuration ─────────────────────────────────────────────────────────────
RABBITMQ_URL = "amqp://guest:guest@localhost:5672/"
QUEUE_NAME   = "inference_logs"

# In-memory "Logs DB"
logs_db: list[dict] = []

# Consumer status — visible via GET /health
consumer_status = {
    "running":        False,
    "connected":      False,
    "messages_received": 0,
    "last_error":     None,
}


# ── RabbitMQ consumer coroutine ───────────────────────────────────────────────
async def consume_logs():
    """
    Long-running background coroutine:
      - Connects to RabbitMQ (retries automatically on disconnect)
      - Listens on 'inference_logs' queue
      - Stores every message in logs_db
    """
    consumer_status["running"] = True
    print("[Logging Service] Consumer task started.")

    try:
        print(f"[Logging Service] Connecting to RabbitMQ at {RABBITMQ_URL} ...")
        connection = await aio_pika.connect_robust(RABBITMQ_URL)
        consumer_status["connected"] = True
        print("[Logging Service] ✓ Connected to RabbitMQ.")

        channel = await connection.channel()
        await channel.set_qos(prefetch_count=1)   # one message at a time

        # Declare durable queue (idempotent — safe if Gateway already declared it)
        queue = await channel.declare_queue(QUEUE_NAME, durable=True)
        print(f"[Logging Service] ✓ Listening on queue '{QUEUE_NAME}' — waiting for messages...")

        async with queue.iterator() as queue_iter:
            async for message in queue_iter:
                async with message.process():     # auto-ack on success
                    try:
                        log_data = json.loads(message.body)
                        logs_db.append(log_data)
                        consumer_status["messages_received"] += 1
                        print(f"[Logging Service] ✓ Stored log #{consumer_status['messages_received']}: {log_data}")
                    except json.JSONDecodeError as e:
                        print(f"[Logging Service] ✗ Bad message body — could not parse JSON: {e}")

    except asyncio.CancelledError:
        print("[Logging Service] Consumer task cancelled (shutdown).")
        raise   # re-raise so asyncio handles it cleanly

    except Exception as exc:
        consumer_status["connected"] = False
        consumer_status["last_error"] = str(exc)
        print(f"[Logging Service] ✗ Consumer crashed: {exc}")
        raise

    finally:
        consumer_status["running"] = False


# ── Lifespan: start / stop background consumer ───────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    consumer_task = asyncio.create_task(consume_logs())

    # Give the consumer a moment to connect before serving traffic
    await asyncio.sleep(0.5)

    if consumer_status["last_error"]:
        print(f"[Logging Service] WARNING — consumer failed on startup: {consumer_status['last_error']}")

    yield   # ← app serves requests here

    consumer_task.cancel()
    try:
        await consumer_task
    except asyncio.CancelledError:
        pass
    print("[Logging Service] Shutdown complete.")


app = FastAPI(title="Logging Service", lifespan=lifespan)


# ── Endpoints ─────────────────────────────────────────────────────────────────
@app.get("/health")
def health():
    """
    Diagnostic endpoint — check this first if /logs is empty.
    Shows whether the RabbitMQ consumer is running and connected.
    """
    return {
        "consumer_running":      consumer_status["running"],
        "rabbitmq_connected":    consumer_status["connected"],
        "messages_received":     consumer_status["messages_received"],
        "logs_stored":           len(logs_db),
        "last_error":            consumer_status["last_error"],
        "queue":                 QUEUE_NAME,
        "rabbitmq_url":          RABBITMQ_URL,
    }


@app.get("/logs")
def get_logs():
    """Return all stored inference logs."""
    return logs_db


@app.get("/logs/count")
def get_log_count():
    """Return the number of stored logs."""
    return {"count": len(logs_db)}


# ── Start server ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8002)
