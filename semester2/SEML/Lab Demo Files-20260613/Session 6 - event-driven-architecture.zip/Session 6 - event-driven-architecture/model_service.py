# model_service.py
# Model Service (FastAPI)
# Responsibilities: inference only
#   - Loads the .pkl model at startup
#   - Exposes POST /predict — receives features, returns prediction

from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import uvicorn

app = FastAPI(title="Model Service")

# Load model once at startup
model = joblib.load("logistic_regression_model.pkl")
print("[Model Service] Model loaded successfully.")


class InputData(BaseModel):
    features: list


@app.post("/predict")
def predict(data: InputData):
    """Run inference and return the predicted class."""
    prediction = model.predict([data.features])
    return {"prediction": int(prediction[0])}


# ── Start server ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8001)
