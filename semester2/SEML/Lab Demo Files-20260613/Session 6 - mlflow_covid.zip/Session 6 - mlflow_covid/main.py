# Installations
# 1. pip install mlflow
# 2. pip install psutil

# Steps to run
# 1. In terminal, run command -> mlflow ui --host 0.0.0.0 --port 5000
# 2. In another terminal, run command -> python main.py
# 3. Open localhost:5000 in browser and see the experimental results

# Import necessary libraries
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix
)
import mlflow
import mlflow.sklearn
from mlflow.tracking import MlflowClient
import psutil
import time
import warnings

warnings.filterwarnings("ignore")

# MLflow Tracking URI
mlflow.set_tracking_uri("http://localhost:5000")

# Model Name for Registry
MODEL_NAME = "Covid_Discharge_RF_Model"


# Function for data preprocessing
def preprocess_data(data):

    # One-hot encoding
    data = pd.get_dummies(
        data,
        columns=['Gender', 'CovidSeverity']
    )

    # Features and target
    X = data.drop('DischargeType', axis=1)
    y = data['DischargeType']

    return X, y


# Function for training
def train_model(
        X_train,
        y_train,
        max_depth=4,
        n_estimators=100):

    clf = RandomForestClassifier(
        max_depth=max_depth,
        n_estimators=n_estimators,
        random_state=42
    )

    clf.fit(X_train, y_train)

    return clf


# Function to evaluate
def evaluate_model(model, X_test, y_test):

    y_pred = model.predict(X_test)

    accuracy = accuracy_score(y_test, y_pred)

    print(f"\nAccuracy: {accuracy:.2f}")

    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))


# Function to log to MLflow
def log_to_mlflow(
        model,
        X_test,
        y_test):

    with mlflow.start_run():

        # Log Parameters
        mlflow.log_param(
            "max_depth",
            model.max_depth
        )

        mlflow.log_param(
            "n_estimators",
            model.n_estimators
        )

        # Prediction Timing
        start_time = time.time()

        y_pred = model.predict(X_test)

        end_time = time.time()

        execution_time = end_time - start_time

        # Metrics
        accuracy = accuracy_score(
            y_test,
            y_pred
        )

        precision = precision_score(
            y_test,
            y_pred,
            average='micro'
        )

        recall = recall_score(
            y_test,
            y_pred,
            average='micro'
        )

        f1 = f1_score(
            y_test,
            y_pred,
            average='micro'
        )

        # Log Metrics
        mlflow.log_metric(
            "accuracy",
            accuracy
        )

        mlflow.log_metric(
            "precision",
            precision
        )

        mlflow.log_metric(
            "recall",
            recall
        )

        mlflow.log_metric(
            "f1_score",
            f1
        )

        mlflow.log_metric(
            "execution_time",
            execution_time
        )

        # Confusion Matrix
        confusion = confusion_matrix(
            y_test,
            y_pred
        )

        # Log only for binary classification
        if confusion.shape == (2, 2):

            confusion_dict = {
                "true_positive": confusion[1][1],
                "false_positive": confusion[0][1],
                "true_negative": confusion[0][0],
                "false_negative": confusion[1][0]
            }

            mlflow.log_metrics(
                confusion_dict
            )

        # System Metrics
        cpu_usage = psutil.cpu_percent(
            interval=1
        )

        memory_usage = psutil.virtual_memory().percent

        mlflow.log_metric(
            "cpu_usage",
            cpu_usage
        )

        mlflow.log_metric(
            "memory_usage",
            memory_usage
        )

        # Evaluate
        evaluate_model(
            model,
            X_test,
            y_test
        )

        # Log + Register Model
        model_info = mlflow.sklearn.log_model(
            sk_model=model,
            artifact_path="model",
            registered_model_name=MODEL_NAME
        )

        # Registry Client
        client = MlflowClient()

        # Get latest version
        latest_version = client.get_latest_versions(
            MODEL_NAME,
            stages=["None"]
        )[0].version

        # Transition to Staging
        client.transition_model_version_stage(
            name=MODEL_NAME,
            version=latest_version,
            stage="Staging"
        )

        print("\nModel Registered Successfully")
        print("Model Name:", MODEL_NAME)
        print("Version:", latest_version)
        print("Stage: Staging")


# Main Function
def main():

    # Load Dataset
    data = pd.read_csv(
        "Covid_data.csv"
    )

    # Preprocess
    X, y = preprocess_data(
        data
    )

    # Split
    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.2,
        random_state=42
    )

    # Train
    model = train_model(
        X_train,
        y_train
    )

    # Log to MLflow
    log_to_mlflow(
        model,
        X_test,
        y_test
    )


if __name__ == "__main__":
    main()