# logging_service.py

from fastapi import FastAPI
from pydantic import BaseModel
import uvicorn

app = FastAPI()

logs = []

class LogData(BaseModel):
    features: list
    prediction: int

@app.post("/log")
def log(data: LogData):

    logs.append(data.dict())

    return {
        "message": "logged"
    }

@app.get("/logs")
def get_logs():
    return logs

# Start server
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8002)