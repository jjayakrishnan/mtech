# model_service.py

from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import uvicorn

app = FastAPI()

model = joblib.load("logistic_regression_model.pkl")

class InputData(BaseModel):
    features: list

@app.post("/predict")
def predict(data: InputData):

    prediction = model.predict([data.features])

    return {
        "prediction": int(prediction[0])
    }

# Start server
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8001)