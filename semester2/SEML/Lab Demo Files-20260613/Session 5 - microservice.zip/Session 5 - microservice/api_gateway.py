# api_gateway.py

from fastapi import FastAPI
from pydantic import BaseModel
import requests
import uvicorn

app = FastAPI()

MODEL_URL = "http://localhost:8001/predict"
LOG_URL = "http://localhost:8002/log"

class InputData(BaseModel):
    features: list

@app.post("/predict")
def predict(data: InputData):

    # Call Model Service
    model_response = requests.post(
        MODEL_URL,
        json={"features": data.features}
    )

    prediction = model_response.json()

    # Call Logging Service
    requests.post(
        LOG_URL,
        json={
            "features": data.features,
            "prediction": prediction["prediction"]
        }
    )

    return prediction

# Start server
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)